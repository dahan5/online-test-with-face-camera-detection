@extends('layout')
@section('content')
    <h2>Test Online</h2>
    <hr>
    <div id="alert-waiting-webcam" class="alert alert-info">
        <strong>Mohon tunggu</strong> sedang membuka webcam...
    </div>
    <div id="question-wrapper" style="display: none">
        <div class="alert alert-warning">
            Mohon untuk fokus pada formulir ini. Ikuti peraturan dan tata carai sebagai berikut :
            <ol>
                <li>Dilarang merefresh ulang halaman ini</li>
                <li>Tidak diperkenankan untuk membuka gadget/smartphone/komputer lain untuk mencari jawaban</li>
                <li>Tidak diperkenankan untuk membuka browser/tab lain untuk mencari jawaban</li>
                <li>Tidak diperkenankan untuk meninggalkan form test online selama berlangsung</li>
                <li>Tidak menggunakan cheat/menipu/meminta bantu orang lain untuk menjawab test online</li>
                <li>Kerjakan test online sesuai dengan waktu yang telah ditentukan</li>
            </ol>
            Segala bentuk pelanggaran akan langsung diskualifikasi.
        </div>
        <p>Silahkan jawab sesuai dengan apa yang Anda ketahui</p>

        <form id="form-test" method="post" action="{{ url('finish-test') }}">
            {!! csrf_field() !!}
            <input type="hidden" name="id" value="{{ $report_test->id }}">
            <ol>
                @foreach($questions as $question)
                    <li>
                        <p><strong>{{ $question->question }}</strong></p>
                        <input type="hidden" name="questions_id[]" value="{{ $question->id }}">
                        <input type="hidden" name="questions_question[]" value="{{$question->question}}">
                        <textarea name="answer[{{$question->id}}]" class="form-control" placeholder="Ketik jawaban disini" required rows="3"></textarea>
                    </li>
                @endforeach
            </ol>

            <br>
            <button class="btn btn-success w-100" onclick="finish()" type="button">Selesai</button>
        </form>
    </div>
    @push("bottom")
        <script src="{{ asset('asset/webgazer.js') }}" type="text/javascript"></script>

        <script>
            let isFinish = false;
            function finish() {
                isFinish = true;
                $("#form-test").submit();
            }
            $(function() {
                let nik = "{{ $report_test->nik }}";
                $(window).blur(function() {
                    if(isFinish === false) {
                        $.post("{{url('api/abort-test')}}", {nik: nik});
                        alert("Anda keluar dari fokus browser!");
                        location.href = '{{ url('?status=diskualifikasi') }}';
                    }
                });
            })
        </script>

        <script>
            let timeout = null;
            let xPred = null;
            let yPred = null;
            let eyeCatch = false;
            let eyeLost = false;

            var targetObj = {};
            var targetProxy = new Proxy(targetObj, {
                set: function (target, key, value) {
                    if(key === 'eyeLost' && value === true) {
                        faceNotDetected();
                    }
                    console.log(`${key} set to ${value}`);
                    target[key] = value;
                    return true;
                }
            });

            function sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }

            async function faceNotDetected()
            {
                webgazer.pause();
                await sleep(1000);
                isFinish = true;
                await alert("Wajah tidak terdeteksi!");
                await $.post("{{ url('api/abort-test') }}");
                location.href = '{{ url('/?status=diskualifikasi') }}';
                await sleep(1500);
            }

            async function main() {
                await webgazer.setGazeListener(function(data, elapsedTime) {
                    if (data == null) {
                        return;
                    }
                    xPred = data.x; //these x coordinates are relative to the viewport
                    yPred = data.y; //these y coordinates are relative to the viewport
                    eyeCatch = true;
                }).begin();

                let check = setInterval(async ()=> {
                    if(eyeCatch) {
                        $("#alert-waiting-webcam").hide();
                        $("#question-wrapper").show();
                        let inside = $("#webgazerFaceFeedbackBox").attr('style');
                        if(inside && inside.includes("solid green") && xPred && yPred) {
                            console.log("Face inside");
                        } else {
                            targetProxy.eyeLost = true;
                            clearInterval(check);
                        }
                    }
                },500);

                let check2 = setInterval(async ()=>{
                    $("#webgazerVideoContainer").attr("style","display:none");
                }, 100);
            }

            main();
        </script>
    @endpush
@endsection
