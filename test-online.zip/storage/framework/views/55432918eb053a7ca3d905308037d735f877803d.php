<?php $__env->startSection('content'); ?>

    <div  style="position: fixed; bottom: 0; left: 0; width: 100%;">
        <div class="alert alert-warning" style="margin-bottom: 0px">
            <strong>Perhatian</strong> <br>
            Mohon pastikan Anda menekan tombol Allow/Yes saat permintaan video record / webcam pada Browser Anda.
        </div>

        <div class="alert alert-info" style="margin-bottom: 0px">
            <div id="status" class="text-center">
                Mohon tunggu pemindaian wajah & mata...
            </div>
        </div>
    </div>


    <div id="face-detector-area"></div>
    <?php $__env->startPush("bottom"); ?>
        <script src="<?php echo e(asset('asset/webgazer.js')); ?>" type="text/javascript"></script>
        <script>
            jQuery.fn.center = function () {
                this.css("position","absolute");
                this.css("top", "50px");
                this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
                    $(window).scrollLeft()) + "px");
                return this;
            }

            let timeout = null;
            let xPred = null;
            let yPred = null;
            let eyeCatch = false;
            let eyeLost = false;

            async function main() {
                await webgazer.setGazeListener(function(data, elapsedTime) {
                    if (data == null) {
                        return;
                    }
                    xPred = data.x; //these x coordinates are relative to the viewport
                    yPred = data.y; //these y coordinates are relative to the viewport
                    eyeCatch = true;
                }).begin();

                let check = setInterval(async ()=> {
                    if(eyeCatch) {
                        let inside = $("#webgazerFaceFeedbackBox").attr('style');
                        if(inside && inside.includes("solid green") && xPred && yPred) {
                            console.log("Human inside");
                            clearTimeout(timeout);
                        } else {
                            timeout = setTimeout(async ()=> {
                                clearInterval(check);
                                webgazer.pause();
                                eyeLost = true;
                            },2000);
                        }
                        $("html,body").attr("style","overflow: hidden");
                        $("#webgazerGazeDot").attr("style","display:none");
                        if(eyeLost === false) {
                            clearInterval(check);
                            $("#status").html("<strong>Wajah dan Mata terdeteksi</strong><br/>Anda akan diarahkan ke formulir test sebentar lagi...");
                            setTimeout(async()=>{
                                await $.post("<?php echo e(url('api/eye-test-completed')); ?>");
                                location.href = '<?php echo e(url('form-test')); ?>';
                            },1500);
                        }
                    }
                },2500);

                let check2 = setInterval(async ()=>{
                    $("#webgazerVideoContainer").center();
                }, 100);
            }

            main();


        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\test-online\resources\views/eye_test.blade.php ENDPATH**/ ?>