<?php $__env->startSection('content'); ?>
    <h2>Test Online</h2>
    <hr>
    <div id="alert-waiting-webcam" class="alert alert-info">
        <strong>Mohon tunggu</strong> sedang membuka webcam...
    </div>
    <div id="question-wrapper" style="display: none">
        <div class="alert alert-warning">
            Mohon untuk fokus pada formulir ini. Ikuti peraturan dan tata carai sebagai berikut :
            <ol>
                <li>Dilarang merefresh ulang halaman ini</li>
                <li>Tidak diperkenankan untuk membuka gadget/smartphone/komputer lain untuk mencari jawaban</li>
                <li>Tidak diperkenankan untuk membuka browser/tab lain untuk mencari jawaban</li>
                <li>Tidak diperkenankan untuk meninggalkan form test online selama berlangsung</li>
                <li>Tidak menggunakan cheat/menipu/meminta bantu orang lain untuk menjawab test online</li>
                <li>Kerjakan test online sesuai dengan waktu yang telah ditentukan</li>
            </ol>
            Segala bentuk pelanggaran akan langsung diskualifikasi.
        </div>
        <p>Silahkan jawab sesuai dengan apa yang Anda ketahui</p>

        <form id="form-test" method="post" action="<?php echo e(url('finish-test')); ?>">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="id" value="<?php echo e($report_test->id); ?>">
            <ol>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <p><strong><?php echo e($question->question); ?></strong></p>
                        <input type="hidden" name="questions_id[]" value="<?php echo e($question->id); ?>">
                        <input type="hidden" name="questions_question[]" value="<?php echo e($question->question); ?>">
                        <textarea name="answer[<?php echo e($question->id); ?>]" class="form-control" placeholder="Ketik jawaban disini" required rows="3"></textarea>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>

            <br>
            <button class="btn btn-success w-100" onclick="finish()" type="button">Selesai</button>
        </form>
    </div>
    <?php $__env->startPush("bottom"); ?>
        <script src="<?php echo e(asset('asset/webgazer.js')); ?>" type="text/javascript"></script>

        <script>
            let isFinish = false;
            function finish() {
                isFinish = true;
                $("#form-test").submit();
            }
            $(function() {
                let nik = "<?php echo e($report_test->nik); ?>";
                $(window).blur(function() {
                    if(isFinish === false) {
                        $.post("<?php echo e(url('api/abort-test')); ?>", {nik: nik});
                        alert("Anda keluar dari fokus browser!");
                        location.href = '<?php echo e(url('?status=diskualifikasi')); ?>';
                    }
                });
            })
        </script>

        <script>
            let timeout = null;
            let xPred = null;
            let yPred = null;
            let eyeCatch = false;
            let eyeLost = false;

            var targetObj = {};
            var targetProxy = new Proxy(targetObj, {
                set: function (target, key, value) {
                    if(key === 'eyeLost' && value === true) {
                        faceNotDetected();
                    }
                    console.log(`${key} set to ${value}`);
                    target[key] = value;
                    return true;
                }
            });

            function sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }

            async function faceNotDetected()
            {
                webgazer.pause();
                await sleep(1000);
                isFinish = true;
                await alert("Wajah tidak terdeteksi!");
                await $.post("<?php echo e(url('api/abort-test')); ?>");
                location.href = '<?php echo e(url('/?status=diskualifikasi')); ?>';
                await sleep(1500);
            }

            async function main() {
                await webgazer.setGazeListener(function(data, elapsedTime) {
                    if (data == null) {
                        return;
                    }
                    xPred = data.x; //these x coordinates are relative to the viewport
                    yPred = data.y; //these y coordinates are relative to the viewport
                    eyeCatch = true;
                }).begin();

                let check = setInterval(async ()=> {
                    if(eyeCatch) {
                        $("#alert-waiting-webcam").hide();
                        $("#question-wrapper").show();
                        let inside = $("#webgazerFaceFeedbackBox").attr('style');
                        if(inside && inside.includes("solid green") && xPred && yPred) {
                            console.log("Face inside");
                        } else {
                            targetProxy.eyeLost = true;
                            clearInterval(check);
                        }
                    }
                },500);

                let check2 = setInterval(async ()=>{
                    $("#webgazerVideoContainer").attr("style","display:none");
                }, 100);
            }

            main();
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\test-online\resources\views/form_test.blade.php ENDPATH**/ ?>