<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

    <title>Test Online</title>
</head>
<body>
<noscript>Please enable your Javascript</noscript>
<div class="container">
    <div style="margin-top: 30px;">
        <h2>Test Online</h2>
        <hr>
        Silahkan jawab sesuai dengan apa yang Anda ketahui
        <ol>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($question->question); ?>

                    <textarea name="answer[<?php echo e($question->id); ?>]" class="form-control" placeholder="Ketik jawaban disini" rows="5"></textarea>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
<script>
    $(function() {
        $(window).blur(function() {
            alert('You are not allowed to leave page blah blah');
            //do something else
        });
    })
</script>
</body>
</html>
<?php /**PATH C:\xampp74\htdocs\test-online\resources\views/main.blade.php ENDPATH**/ ?>